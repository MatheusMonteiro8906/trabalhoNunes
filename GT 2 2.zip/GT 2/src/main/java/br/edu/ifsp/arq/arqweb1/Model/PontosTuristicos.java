package br.edu.ifsp.arq.arqweb1.Model;

public class PontosTuristicos {
	public class TouristPoint {
	    private int id;
	    private String nome;
	    private String localização;
	    private String descrição;
	    private String horas;
	    private int custoDeEntrada;
	    private String photo;
	    private int avaliação;
	    
	}

	public class Category {
	    private int id;
	    private String name;
	}
}
